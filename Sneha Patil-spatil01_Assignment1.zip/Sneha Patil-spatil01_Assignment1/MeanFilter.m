function MF = MeanFilter(A,m)
originalImage = imread(A);
subplot(2,1,1);
imshow(originalImage, []);
title('Original Image');
kernel = (ones(m,m))/m^2;
outPutImg = conv2(originalImage, kernel);
subplot(2,1, 2);
imshow(outPutImg, []);
title('Image filtered with an smooth averaging filter');
MF = outPutImg;