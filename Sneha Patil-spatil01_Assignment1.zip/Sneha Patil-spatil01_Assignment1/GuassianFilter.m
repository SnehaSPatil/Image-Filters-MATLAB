function MF = GuassianFilter(A,sigma)
sz = ceil(5 * sigma);
originalImage = imread(A);
I = padarray(originalImage,[floor(sz/2) floor(sz/2)]);
subplot(2,1,1);
imshow(originalImage, []);
title('Original Image');
x = linspace(-sz / 2, sz / 2, sz);
Exp_comp = -(x.^2)/(2*sigma*sigma);
kernel= exp(Exp_comp)/(2*pi*sigma*sigma);
M= min(kernel);
kernelN = int16(kernel / M);
 for i = 1:size(originalImage,1)
    for j =1:size(originalImage,2)
        Temp = double(I(i + floor(sz/2),j:j+sz-1)).*double(kernelN);
        Ir(i,j)=sum(Temp(:))/ sum(kernelN);
    end
 end
I = padarray(Ir,[floor(sz/2) floor(sz/2)]);
  for j = 1:size(originalImage,2)
    for i =1:size(originalImage,1)
        Temp = double(I(i:i+sz-1,j + floor(sz/2))).*double(kernelN);
        Io(i,j)=sum(Temp(:))/ sum(kernelN);
    end
  end
outPutImg = Io;
subplot(2,1,2);
imshow(outPutImg, []);
title('Image filtered with an Guassian filter');
MF = outPutImg;