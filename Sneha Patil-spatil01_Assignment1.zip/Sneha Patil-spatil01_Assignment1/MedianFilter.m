function MF = MedianFilter(A,N)
originalImage = imread(A);
subplot(2,1,1);
imshow(originalImage, []);
title('Original Image');
im_pad = padarray(originalImage, [floor(N/2) floor(N/2)]);
B=zeros(size(A));
 for i= 1:size(im_pad,1)- N/2 -N/2
    for j=1:size(im_pad,2)-N/2 -N/2
        window=zeros(N^2,1);
        inc=1;
        for x=1:N
            for y=1:N
                window(inc)=im_pad(i+x-1,j+y-1);
                inc=inc+1;
            end
        end
       
        med=sort(window);
        %PLACE THE MEDIAN ELEMENT IN THE OUTPUT MATRIX
        B(i,j)=med(floor(N*N/2)+1);
       
    end
 end 
outPutImg = uint8(B);

subplot(2,1, 2);
imshow(outPutImg, []);
title('Image filtered with an Median filter');
MF = outPutImg;